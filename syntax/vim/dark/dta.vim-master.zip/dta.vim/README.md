# dta.vim

vim plugin for hmx milo engine dta scripts